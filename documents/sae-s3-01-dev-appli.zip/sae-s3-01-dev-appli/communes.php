<?php
$titre = "Nos communes membres | CAGSC";
$urlstyle = "css/communes.css";
require_once("include/header.php");
?>
<div id="communes">
    <h1>Les communes membres</h1>
</div>
<div id="conteneurCarteCommunes">
    <div id="carteCommunes"></div>
</div>
<script src="javascript/communes.js"></script>
<?php
require_once("include/footer.php");
?>