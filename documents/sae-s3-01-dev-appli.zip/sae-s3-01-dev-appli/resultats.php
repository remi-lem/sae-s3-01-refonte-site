<?php
$titre = "Résultats de l'enquête | CAGSC";
$urlstyle = "css/resultats.css";
require_once("include/header.php");
?>
<h1 id="titreResults">Résultats de l'enquête</h1>
<div id="resultats">
    <h2>RESULTATS</h2>
    <p>ICI LES RESULTATS</p>
    <!-- TODO-->
</div>

<?php
require_once("include/footer.php");
?>